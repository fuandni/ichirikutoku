一陸特 統合サイト

構成:
- index.html: 4教材ホーム
- houki-textbook/: 法規・教材
- houki-practice/: 法規・演習（スマホ版）
- kogaku-v1/: 無線工学 v1（432問フル版）
- kogaku-v2/: 無線工学 v2（GitHub main の現行版を配置）

OCIでは、このディレクトリ以下を同じ公開ルートへ配置してください。
